import numpy as np,pandas as pd, math, json
from datetime import timedelta
from scipy.special import ndtr
from dateutil.relativedelta import relativedelta
SEED=20261028
rng=np.random.default_rng(SEED)
D=pd.read_csv('/mnt/data/Dictionary (5)(20261028-141024).csv',sep=';',encoding='utf-8-sig')
COLS=['patient_id']+[x for x in D['Variable name'] if x!='patient_id']
N=5000

def rand(p):return int(rng.random()<p)
def normal(m,s):return float(rng.normal(m,s))
def intval(m,s,lo=None,hi=None):
 for j in range(1000):
  v=int(round(normal(m,s)))
  if (lo is None or v>=lo) and (hi is None or v<=hi):return v
 raise ValueError('support')
def nval(m,s,lo=None,hi=None,d=1):
 for j in range(1000):
  v=round(normal(m,s),d)
  if (lo is None or v>=lo) and (hi is None or v<=hi):return v
 raise ValueError('support')
def choice(v,p=None):return rng.choice(v,p=p).item() if hasattr(rng.choice(v,p=p),'item') else rng.choice(v,p=p)
def date(d):return d.strftime('%Y-%m-%d')
def bp(ms,md,ss=8,sd=6,loS=75,hiS=210,loD=40,hiD=130):
 for _ in range(1000):
  x,y=rng.multivariate_normal([ms,md],[[ss*ss,.52*ss*sd],[.52*ss*sd,sd*sd]])
  a,b=int(round(x)),int(round(y))
  if loS<=a<=hiS and loD<=b<=hiD and a>b:return a,b
 raise ValueError('BP support')
def efw(ac_mm,hc_mm):
 ac=ac_mm/10;hc=hc_mm/10
 return int(round(math.exp(5.084820-54.06633*(ac/100)**3-95.80076*(ac/100)**3*math.log(ac/100)+3.136370*(hc/100))))
def percentile(weight,week):
 lam=-4.257629-2162.234*week**-2+.0002301829*week**3
 mu=4.956737+.0005019687*week**3-.0001227065*week**3*math.log(week)
 sigma=1e-4*(-6.997171+.057559*week**3-.01493946*week**3*math.log(week))
 y=math.log(weight)
 if y<=0 or sigma<=0:return None
 z=((y/mu)**lam-1)/(sigma*lam) if abs(lam)>1e-6 else math.log(y/mu)/sigma
 return 100*ndtr(z)
# approximate birth mass expected weight by gestational week: explicit synthetic modeling aid, NOT a clinical reference table
NEO={20:360,22:480,24:640,26:850,28:1100,30:1400,32:1760,34:2220,36:2670,37:2910,38:3110,39:3290,40:3430,41:3540,42:3650,43:3720}

def make(profile):
 r={k:pd.NA for k in COLS}
 # synthetic profile conditions condition trajectories, NOT exported
 is_control=profile=='A'; pdm=rand(.013 if not is_control else .002)
 age=intval(30 if is_control else 33,5.5,17,48)
 ht=nval(1.64,.073,1.43,1.87,2)
 bmi_lat=normal(23.5 if is_control else 28.0,4.6 if is_control else 6.2)
 bmi_lat=min(47,max(17.1,bmi_lat))
 w1=round(bmi_lat*ht**2,1)
 bmi=round(w1/ht**2,2)
 gest_shift=rand(.13) * intval(0,4,-10,10)
 lmp=pd.Timestamp('2025-01-01')+pd.Timedelta(days=int(rng.integers(0,560)))
 # full first trimester measurement and adjustment
 uscal=int(rng.integers(74,96));diff=int(round(rng.triangular(-10,0,10)))
 if not 63<=uscal+diff<=97:return None
 usdate=lmp+pd.Timedelta(days=uscal);usga=uscal+diff
 edd=lmp+pd.Timedelta(days=280)
 adjusted=(usdate+pd.Timedelta(days=280-usga)) if abs(diff)>=7 else edd
 origin=adjusted-pd.Timedelta(days=280)
 def day(g):return origin+pd.Timedelta(days=int(g))
 # baseline
 r.update(maternal_age=age,height_m=ht,visit1_weight_kg=w1,bmi=bmi,last_menstrual_period=date(lmp),estimated_due_date=date(edd),ultrasound_adjusted_estimated_due_date=date(adjusted),first_trimester_ultrasound_date=date(usdate),gestational_age_at_first_trimester_ultrasound_days=usga,dating_confirmed_by_first_trimester_ultrasound=int(abs(diff)<7))
 r['preconception_consultation_recorded']=rand(.24)
 r['preconception_consultation_date']=date(lmp-pd.Timedelta(days=int(rng.integers(20,170)))) if r['preconception_consultation_recorded'] else pd.NA
 v1day=int(rng.integers(42,69));r['visit1_date']=date(day(v1day))
 for k,p in [('pregestational_diabetes',.02 if not is_control else 0),('epilepsy_on_anticonvulsants',.012),('folate_metabolism_disorder',.009),('celiac_disease',.016),('inflammatory_bowel_disease',.017),('methotrexate_use',.003),('trimethoprim_use',.012),('previous_child_with_NTD',.006),('family_history_of_NTD',.017),('previous_hepatitis_B_vaccination',.80),('alcohol_use',.095),('tobacco_use',.13),('other_psychoactive_substance_use',.024),('intimate_partner_violence',.038)]:r[k]=rand(p)
 r['pregestational_diabetes']=pdm if not is_control else 0
 r['high_risk_folic_acid_indication']=int(any(r[k] for k in ['previous_child_with_NTD','family_history_of_NTD','epilepsy_on_anticonvulsants','folate_metabolism_disorder','methotrexate_use']))
 r['folic_acid_started']=rand(.93);r['folic_acid_stopped']=rand(.06) if r['folic_acid_started'] else 0
 r['folic_acid_dose']=(5000 if r['high_risk_folic_acid_indication'] else 400) if r['folic_acid_started'] else pd.NA
 r['potassium_iodide_started']=rand(.93)
 r['blood_group']=choice(['A','B','AB','O'],[.46,.09,.04,.41]);r['RhD']=rand(.84)
 for k,p in [('HBsAg_first_trimester',.009),('HIV1_HIV2_antibodies_first_trimester',.003),('indirect_coombs_first_trimester',.023),('rubella_first_trimester',.89),('toxoplasmosis_first_trimester',.35)]:r[k]=rand(p)
 r['cervical_cytology_status']=choice(['normal','altered','pending','not done'],[.78,.07,.06,.09]);r['combined_screening_risk']=choice(['low','high'],[.93,.07]);r['PAPP_A']=nval(1.15,.46,.2,4.5,2);r['beta_hCG']=nval(1.18,.58,.2,5,2);r['nuchal_translucency_value']=nval(1.65,.48,.6,4.7,1)
 # early glycemia, GDM probability linked to profile/risk and not forced to threshold
 gdm_lat=profile in ['B','H'] or (not is_control and rand(.10+ .06*(bmi>30)))
 fgmean=99 if gdm_lat else (82 if is_control else 85)
 r['fasting_glucose']=intval(fgmean + 3*(bmi>30)+3*(age>=35),11,63,150)
 if r['pregestational_diabetes']:r['fasting_glucose']=intval(111,18,82,170)
 r['hemoglobin_first_trimester']=nval(11.7 if profile=='F' else 12.1,1.08,7.5,16,1)
 r['anemia_first_trimester']=int(r['hemoglobin_first_trimester']<11)
 r['hemoglobin_second_trimester']=nval(r['hemoglobin_first_trimester']-.55,.6,7.1,16,1)
 r['anemia_second_trimester']=int(r['hemoglobin_second_trimester']<10.5)
 # hypertension: latent trajectories drives correlated paired measurements
 h_lat=profile in ['C','D','H'] or (not is_control and rand(.10+.05*(bmi>=30)))
 pe_lat=profile in ['D','H'] or (h_lat and rand(.20))
 sys0=112+5*(bmi>=30)+2*(age>=35)+normal(0,7)
 dia0=69+3*(bmi>=30)+normal(0,5)
 r['blood_pressure_week6_systolic'],r['blood_pressure_week6_diastolic']=bp(sys0,dia0)
 r['blood_pressure_week16_systolic'],r['blood_pressure_week16_diastolic']=bp(sys0+2,dia0+1)
 # age at birth modeled from mechanism and latent risks; derive actual GA from integer birth day
 pt_lat=(profile=='F' or (profile in ['D','H'] and rand(.30)) or (not is_control and rand(.055+.05*r['anemia_first_trimester'])))
 if is_control:pt_lat=False
 if pt_lat:
  band=choice(['late','moderate','very','extreme'],[.70,.12,.12,.06]);ranges={'late':(238,259),'moderate':(224,238),'very':(196,224),'extreme':(161,196)}
  dl=int(rng.integers(*ranges[band]))
 else:dl=intval(279 if is_control else 274,10,259,294)
 # occasional control false starts removed through selection; chronology
 delivery=day(dl)
 r['delivery_date']=date(delivery);ga=round(dl/7,2)
 r['gestational_age_at_delivery_weeks']=ga;r['preterm_birth']=int(ga<37)
 if not r['preterm_birth'] and profile=='F':return None
 # visits gated by delivery
 windows={2:(98,119),3:(140,155),4:(196,211),5:(224,231),6:(238,253),7:(252,278)}
 actual={1:v1day}
 for k,(low,high) in windows.items():
  v=int(rng.integers(low,high))
  if v<dl and rng.random()>.025:
   actual[k]=v;r[f'visit{k}_date']=date(day(v))
 # weight model accumulation with term BMI targets, nonlinear trajectory
 targets=[(18.5,15.6),(25,13.7),(30,9.3),(100,7.1)]
 gainbase=next(val for cut,val in targets if bmi<cut)+normal(0,2.2)
 def gain(g):
  first=1.0
  frac=max(0,min(1,(g-91)/(280-91)))
  return first+ (gainbase-first)*frac**1.08 +normal(0,.30)
 for k,g in actual.items():
  if k>1:r[f'visit{k}_weight_kg']=round(w1+gain(g)-gain(v1day),1)
 antenatal=round(r[f'visit{max(actual)}_weight_kg'] if max(actual)>1 else w1,1)
 r['total_weight_gain']=round(antenatal-w1,1)
 for k in range(2,8):
  if k in actual:
   r[f'fetal_heartbeat_present_visit{k}']=1
   r[f'potassium_iodide_supplementation_visit{k}']=int(bool(r['potassium_iodide_started']) and rand(.935))
 for k in [3,4,5,6]:
  if k in actual:
   score=intval(2.0+1.15*(h_lat or gdm_lat)+1.1*(k>=5),2.3,0,15)
   r[f'Goodwin_score_visit{k}']=score;r[f'Goodwin_risk_visit{k}']='low' if score<=2 else 'medium' if score<=6 else 'high'
 if 3 in actual:
  wg=actual[3]/7
  r['biparietal_diameter_second_trimester']=nval(53+2*(wg-21),3.3,38,72,1)
  r['abdominal_circumference_second_trimester']=nval(170+9*(wg-21),13,125,230,1)
  r['head_circumference_second_trimester']=nval(194+9*(wg-21),12,150,260,1)
  r['femur_length_second_trimester']=nval(36+2*(wg-21),3.4,24,50,1)
  r['second_trimester_anatomy_scan']=choice(['normal','altered'],[.94,.06])
  if not r['rubella_first_trimester']:r['rubella_second_trimester']=rand(.03)
  if not r['toxoplasmosis_first_trimester']:r['toxoplasmosis_second_trimester']=rand(.035)
 if 4 in actual:r['indirect_coombs_second_trimester']=rand(.03) if not r['indirect_coombs_first_trimester'] else 1
 # glucose test only if reaches chosen OGTT timing
 ogtt_day=int(rng.integers(168,196));ogtt=(r['fasting_glucose']<92 and not r['pregestational_diabetes'] and dl>ogtt_day and rng.random()<.985)
 r['OGTT_performed']=int(ogtt)
 if ogtt:
  r['OGTT_fasting_glucose']=intval(92 if gdm_lat else 80,12,53,145)
  r['OGTT_1h_glucose']=intval(187 if gdm_lat else 144,25,65,260)
  r['OGTT_2h_glucose']=intval(159 if gdm_lat else 119,23,55,250)
 ogttp=ogtt and (r['OGTT_fasting_glucose']>=92 or r['OGTT_1h_glucose']>=180 or r['OGTT_2h_glucose']>=153)
 dg=(not r['pregestational_diabetes']) and ((92<=r['fasting_glucose']<126) or (r['fasting_glucose']<92 and ogttp and r['OGTT_fasting_glucose']<126 and r['OGTT_2h_glucose']<200))
 r['referred_to_gestational_diabetes_clinic']=int(bool(r['pregestational_diabetes']) or r['fasting_glucose']>=92 or ogttp)
 # repeated BP and proteinuria only when week29 reached; conditioned on latent trajectory
 if dl>=203:
  high= h_lat and (rng.random()<.84)
  ms=(151 if high else 119)+4*(bmi>30);md=(98 if high else 74)+2*(bmi>30)
  s1,d1=bp(ms,md,11,8,75,208,42,126)
  s2,d2=bp(ms+normal(0,4),md+normal(0,3),10,7,80,200,40,130)
  r['blood_pressure_week29_systolic']=s1;r['blood_pressure_week29_diastolic']=d1
  r['repeated_third_trimester_blood_pressure_systolic']=s2;r['repeated_third_trimester_blood_pressure_diastolic']=d2
  r['third_trimester_24h_proteinuria_mg']=intval(550 if pe_lat and high else 135,200 if pe_lat and high else 70,0,4000)
  confirm=((s1>=140 or d1>=90) and (s2>=140 or d2>=90) and ((s1+s2)/2>=140 or (d1+d2)/2>=90))
  r['preeclampsia']=int(confirm and r['third_trimester_24h_proteinuria_mg']>=300)
  r['gestational_hypertension']=int(confirm and r['third_trimester_24h_proteinuria_mg']<300)
 # third trimester hemoglobin once reaches 28w
 if dl>=196:
  r['hemoglobin_third_trimester']=nval(r['hemoglobin_second_trimester']+.25,.60,7,16,1)
  r['anemia_third_trimester']=int(r['hemoglobin_third_trimester']<11)
 # fetal growth US at 31-33w only if observed, 22-40 week IG validity
 scan_day=int(rng.integers(217,231))
 growth_lat=profile in ['G','H'] or (not is_control and rand(.10+.09*bool(r.get('preeclampsia') is not pd.NA and r.get('preeclampsia')==1)))
 large_lat=profile in ['E','B'] or (not is_control and rand(.11+.07*bool(dg)))
 if growth_lat:large_lat=False
 birthgrowth=normal(-1.7 if growth_lat else (1.15 if large_lat else 0),.50 if growth_lat else .75)
 if dl>scan_day:
  scanweek=scan_day/7
  # bivariate fetal circumference, adjust growth relative to nominal reference
  # choose AC, HC correlated; reconstruct EFW from exported AC/HC using published IG formula
  # inverse target for AC by numeric grid search against desired IG median based on lambda-mu-sigma
  lam=-4.257629-2162.234*scanweek**-2+.0002301829*scanweek**3
  mu=4.956737+.0005019687*scanweek**3-.0001227065*scanweek**3*math.log(scanweek)
  sig=1e-4*(-6.997171+.057559*scanweek**3-.01493946*scanweek**3*math.log(scanweek))
  z=birthgrowth+normal(0,.27)
  if 1+z*sig*lam<=0:return None
  expected=math.exp(mu*(1+z*sig*lam)**(1/lam))
  hc=round(294+8.7*(scanweek-31)+normal(0,7)+birthgrowth*2,1)
  ac_target=250+10*(scanweek-31)
  # solve by bisection, retaining physiological AC range
  lower,upper=170,385
  for _ in range(35):
   mid=(lower+upper)/2
   if efw(mid,hc)<expected:lower=mid
   else:upper=mid
  ac=round((lower+upper)/2+normal(0,1.2),1)
  if not (180<ac<385 and 235<hc<370):return None
  r['abdominal_circumference_third_trimester']=ac;r['head_circumference_third_trimester']=hc
  r['femur_length_third_trimester']=nval(60+1.7*(scanweek-31)+birthgrowth*.8,2.5,46,80,1)
  ew=efw(ac,hc);pc=percentile(ew,scanweek)
  if pc is None:return None
  ip=int(math.floor(pc+.5))
  if not 1<=ip<=99:return None
  r['estimated_fetal_weight_third_trimester']=ew
  r['estimated_fetal_weight_third_trimester_percentile']=ip
  r['fetal_growth_restriction']=int(ip<10)
 # newborn mass: gestational-age interpolation with log residual and correlated antenatal growth
 xs=np.array(sorted(NEO));ys=np.array([NEO[t] for t in xs])
 base=float(np.interp(ga,xs,ys))
 # log-scale conditional: physiological approximation not exact published birth weight reference
 mass=int(round(base*math.exp(.105*birthgrowth+normal(0,.086))))
 if not 300<=mass<=6000:return None
 if (r['fetal_growth_restriction'] is not pd.NA and r['fetal_growth_restriction']==1 and mass>=4000):return None
 r['birth_weight_g']=mass;r['macrosomia']=int(mass>=4000)
 if profile=='E' and not r['macrosomia']:return None
 if profile=='G' and (r['fetal_growth_restriction'] is pd.NA or not r['fetal_growth_restriction']):return None
 if profile=='C' and r['gestational_hypertension'] is not pd.NA and not r['gestational_hypertension']:return None
 if profile=='D' and r['preeclampsia'] is not pd.NA and not r['preeclampsia']:return None
 if profile=='B' and not dg:return None
 if is_control and (dg or r['pregestational_diabetes'] or r['preterm_birth'] or r['macrosomia'] or r['fetal_growth_restriction'] is pd.NA or r['fetal_growth_restriction'] or r['gestational_hypertension'] is pd.NA or r['gestational_hypertension'] or r['preeclampsia'] or not ogtt or ogttp or r['fasting_glucose']>=92):return None
 # late serologies, GBS, delivery
 if dl>=196:
  r['HIV1_HIV2_antibodies_third_trimester']=rand(.004)
  if not r['previous_hepatitis_B_vaccination'] and not r['HBsAg_first_trimester']:r['HBsAg_third_trimester']=rand(.008)
  if r['toxoplasmosis_second_trimester'] is not pd.NA and r['toxoplasmosis_second_trimester']==0:r['toxoplasmosis_third_trimester']=rand(.02)
 if dl>=245:r['GBS_result']=rand(.17)
 r['fetal_presentation']=choice(['cephalic','pelvic','other'],[.92,.065,.015])
 r['Bishop_score']=intval(5.2,2.3,0,13)
 r['referral_hospital_consultation']=rand(.77);r['instructed_on_fetal_movement_counting']=int(dl>=196 and rand(.95))
 r['labor_induction']=rand(.16+.26*bool(dg)+.30*bool(r['preeclampsia'] is not pd.NA and r['preeclampsia']==1)) if dl>=238 else rand(.22)
 cesp=min(.84,.19+.13*(bmi>30)+.11*(age>=35)+.10*bool(dg)+.22*bool(r['preeclampsia'] is not pd.NA and r['preeclampsia']==1)+.13*(r['fetal_presentation']!='cephalic'))
 r['delivery_type']=choice(['vaginal','cesarean section','instrumental vaginal delivery'],[1-cesp-.09,cesp,.09])
 r['intrapartum_antibiotic_prophylaxis']=int((r['GBS_result'] is not pd.NA and r['GBS_result']==1) or (dl<259 and rand(.23)))
 # puerperium weeks 4-6; Hb specifically early postpartum 1-3 days
 v8=delivery+pd.Timedelta(days=int(rng.integers(28,43)))
 r['visit8_date']=date(v8)
 t4=delivery+relativedelta(months=4)+pd.Timedelta(days=int(rng.integers(-4,7)))
 t6=delivery+relativedelta(months=6)+pd.Timedelta(days=int(rng.integers(-4,7)))
 r['date_4_months_postpartum']=date(t4);r['date_6_months_postpartum']=date(t6)
 r['visit8_weight_kg']=round(antenatal-normal(5.9,2.3),1)
 r['postpartum_weight_loss']=round(antenatal-r['visit8_weight_kg'],1)
 r['weight_4_months_postpartum_kg']=round(r['visit8_weight_kg']-normal(.65,1.1),1)
 r['weight_6_months_postpartum_kg']=round(r['weight_4_months_postpartum_kg']-normal(.42,1.0),1)
 r['postpartum_hemoglobin']=nval((r['hemoglobin_third_trimester'] if r['hemoglobin_third_trimester'] is not pd.NA else r['hemoglobin_second_trimester'])-normal(.8,.55),.5,7,16,1)
 r['postpartum_anemia']=int(r['postpartum_hemoglobin']<10)
 r['postpartum_blood_pressure_systolic'],r['postpartum_blood_pressure_diastolic']=bp(126+10*bool(r['preeclampsia'] is not pd.NA and r['preeclampsia']==1),78+5*bool(r['gestational_hypertension'] is not pd.NA and r['gestational_hypertension']==1),9,7)
 r['uterine_fundal_height_postpartum']=int(choice([0,1,2,3,4],[.935,.04,.015,.008,.002]))
 r['postpartum_temperature']=nval(36.65,.32,35.5,39.1,1)
 r['scar_healing_normal']=rand(.95);r['lochia_normal']=rand(.96);r['pelvic_floor_status']=choice(['normal','altered'],[.82,.18])
 r['EPDS_score']=intval(7.2+1.5*r['intimate_partner_violence'],4.1,0,30)
 r['EPDS_ge_12']=int(r['EPDS_score']>=12)
 r['referred_to_mental_health']=int(r['EPDS_ge_12'] or rand(.045))
 score=intval(2.8+1.0*r['EPDS_ge_12'],2.1,0,15);r['Goodwin_score_visit8']=score;r['Goodwin_risk_visit8']='low' if score<=2 else 'medium' if score<=6 else 'high'
 r['potassium_iodide_supplementation_visit8']=int(bool(r['potassium_iodide_started']) and rand(.94))
 r['contraceptive_method']=choice(['pill','IUD','barrier','implant','none','other'],[.27,.17,.22,.10,.18,.06]);r['contraceptive_method_in_use']=int(r['contraceptive_method']!='none')
 r['breastfeeding_postpartum']=choice(['exclusive','mixed','artificial'],[.66,.25,.09]);basefeed=r['breastfeeding_postpartum']
 transitions={'exclusive':[.65,.27,.08],'mixed':[.16,.56,.28],'artificial':[.03,.15,.82]}
 r['breastfeeding_4_months']=choice(['exclusive','mixed','artificial'],transitions[basefeed])
 trans6={'exclusive':[.36,.55,.09],'mixed':[.05,.71,.24],'artificial':[.02,.10,.88]}
 r['breastfeeding_6_months']=choice(['exclusive','mixed','artificial'],trans6[r['breastfeeding_4_months']])
 for mo in [4,6]:r[f'potassium_iodide_supplementation_{mo}_months']=int(r[f'breastfeeding_{mo}_months']!='artificial' and bool(r['potassium_iodide_started']) and rand(.92))
 r['AUDIT_result']=int(bool(r['alcohol_use']) and rand(.33))
 # 3-7% optional missing in selected NON-CRITICAL ancillary fields
 for c in ['cervical_cytology_status','PAPP_A','beta_hCG','nuchal_translucency_value','pelvic_floor_status']:
  if rng.random()<.045:r[c]=pd.NA
 return r,dict(profile=profile,ogtt_date=date(day(ogtt_day)) if ogtt else None,growth_ultrasound_date=date(day(scan_day)) if dl>scan_day else None,gestational_origin=date(origin),gdm_operational=int(dg),continuous_growth_percentile=round(pc,4) if dl>scan_day else None,neonatal_sex_auxiliary=choice(['female','male']))

profiles=['A']*1600+['B']*650+['C']*510+['D']*400+['E']*650+['F']*700+['G']*430+['H']*60
# use sample profile targets with automatic supplementation by full-trajectory selection
rows=[];meta=[]
for p in profiles:
 for attempt in range(2000):
  o=make(p)
  if o is not None:
   r,m=o;rows.append(r);meta.append(m);break
 else:raise RuntimeError('Cannot produce profile '+p)
print('initial',len(rows))
# 5500 profiles initially! select full trajectories until target with constraints / can reorder sample
main=pd.DataFrame(rows,columns=COLS)
main.insert(0,'x',range(len(main)));main=main.drop(columns=['x'])
main['patient_id']=[f'P{i:05}' for i in range(1,5001)]
metadata=pd.DataFrame(meta);metadata.insert(0,'patient_id',main['patient_id'])
# approximate complete operational GDM classification, explicit non-exported aux data
m=main
og=m['OGTT_performed']==1
fg=m['fasting_glucose'];dg=(m['pregestational_diabetes']==0) & (((fg>=92)&(fg<126))|((fg<92)&og&((m['OGTT_fasting_glucose']>=92)|(m['OGTT_1h_glucose']>=180)|(m['OGTT_2h_glucose']>=153))&(m['OGTT_fasting_glucose']<126)&(m['OGTT_2h_glucose']<200)))
metadata['gdm_operational']=dg.astype('int8')
control=(m['pregestational_diabetes']==0)&(fg<92)&og&(m['OGTT_fasting_glucose']<92)&(m['OGTT_1h_glucose']<180)&(m['OGTT_2h_glucose']<153)&(m['gestational_hypertension']==0)&(m['preeclampsia']==0)&(m['macrosomia']==0)&(m['preterm_birth']==0)&(m['fetal_growth_restriction']==0)
metadata['demonstrable_control']=control.astype('int8')
# conservative lack of evidence tag
indet=m['preeclampsia'].isna()|m['gestational_hypertension'].isna()|m['fetal_growth_restriction'].isna()|((fg<92)&~og)
metadata['insufficient_target_observation']=indet.astype('int8')
flags={'DG operacional':dg,'Hipertensão gestacional':m['gestational_hypertension']==1,'Pré-eclâmpsia':m['preeclampsia']==1,'Macrossomia':m['macrosomia']==1,'Parto pré-termo':m['preterm_birth']==1,'Restrição crescimento fetal':m['fetal_growth_restriction']==1,'Controlos demonstráveis':control}
rep=[]
for k,v in flags.items():
 observed=(~m['gestational_hypertension'].isna()) if k=='Hipertensão gestacional' else (~m['preeclampsia'].isna()) if k=='Pré-eclâmpsia' else (~m['fetal_growth_restriction'].isna()) if k=='Restrição crescimento fetal' else pd.Series(True,index=m.index)
 rep.append({'Condição':k,'N_positivo':int(v.sum()),'Percentagem_total':round(100*v.sum()/N,2),'N_observavel':int(observed.sum()),'Percentagem_observavel':round(100*v.sum()/observed.sum(),2),'Mínimo_proposto':{'DG operacional':700,'Hipertensão gestacional':500,'Pré-eclâmpsia':350,'Macrossomia':650,'Parto pré-termo':750,'Restrição crescimento fetal':500,'Controlos demonstráveis':1500}[k]})
report=pd.DataFrame(rep)
print(report.to_string(index=False))
print('indeterminate',indet.sum())
print('support',m[['repeated_third_trimester_blood_pressure_systolic','repeated_third_trimester_blood_pressure_diastolic']].describe())
# Expand original dictionary, retaining original descriptions and provenance
expanded=D.copy()
expanded=expanded.rename(columns={'Variable name':'nome','Type':'tipo_original','Description / categories':'significado_original','Harvest time':'momento_original','Normal or expected value':'valor_esperado_original','Reference_Link':'fonte_original','Allowed_values':'valores_permitidos_original','Base_variable_for_derivation':'bases_originais','Derivation_rule':'regra_original'})
expanded['tipo_semantico']=expanded['tipo_original'].replace({'Continuous':'numérica','Ordinal':'ordinal','Binary':'binária','Date':'data','Categorical':'categórica'})
expanded['tipo_exportado']=expanded['tipo_original'].map({'Continuous':'numérico','Ordinal':'inteiro','Binary':'inteiro 0/1','Date':'ISO AAAA-MM-DD','Categorical':'texto categórico'})
expanded['codificacao']='Conforme valores_permitidos_original; NA = não observado/não aplicável'
expanded.loc[expanded.tipo_original=='Binary','codificacao']='0 = não/negativo; 1 = sim/positivo; NA = ausência observacional'
expanded['unidade_precisao']=expanded['valores_permitidos_original'].fillna('A confirmar no dicionário')
expanded['momento_colheita']=expanded['momento_original']
expanded['variaveis_base']='não aplicável'
expanded['regra_derivacao']='medição sintética direta / não derivada'
expanded['auditabilidade']='medição direta sintética; não é reconstruível como derivação'
def derived(n,b,rule,a='integral (quando bases presentes)'):
 ix=expanded['nome']==n;expanded.loc[ix,'variaveis_base']=' + '.join(b);expanded.loc[ix,'regra_derivacao']=rule;expanded.loc[ix,'auditabilidade']=a
for n,hb,cut in [('anemia_first_trimester','hemoglobin_first_trimester',11),('anemia_second_trimester','hemoglobin_second_trimester',10.5),('anemia_third_trimester','hemoglobin_third_trimester',11),('postpartum_anemia','postpartum_hemoglobin',10)]:derived(n,[hb],f'1 se {hb} < {cut}; 0 caso contrário; NA se base NA')
for n,base,thr in [('preterm_birth','gestational_age_at_delivery_weeks',37),('macrosomia','birth_weight_g',4000),('fetal_growth_restriction','estimated_fetal_weight_third_trimester_percentile',10),('EPDS_ge_12','EPDS_score',12)]:derived(n,[base],f'1 se {base} '+('>=' if n in ['macrosomia','EPDS_ge_12'] else '<')+f' {thr}; 0 caso contrário; NA se base NA')
derived('estimated_due_date',['last_menstrual_period'],'DUM + 280 dias')
derived('bmi',['visit1_weight_kg','height_m'],'arredondar(visit1_weight_kg / height_m², 2)')
derived('ultrasound_adjusted_estimated_due_date',['first_trimester_ultrasound_date','last_menstrual_period','gestational_age_at_first_trimester_ultrasound_days','estimated_due_date'],'discrepância = idade ecográfica − (data ecografia − DUM); se abs <7, EDD original; senão ecografia + (280 − idade ecográfica) dias')
derived('gestational_age_at_delivery_weeks',['delivery_date','ultrasound_adjusted_estimated_due_date'],'arredondar((delivery_date − (EDD ajustada − 280 dias))/7, 2)')
derived('dating_confirmed_by_first_trimester_ultrasound',['first_trimester_ultrasound_date','last_menstrual_period','gestational_age_at_first_trimester_ultrasound_days'],'1 se discrepância absoluta <7 dias, senão 0; convenção operacional do projeto')
derived('high_risk_folic_acid_indication',['previous_child_with_NTD','family_history_of_NTD','epilepsy_on_anticonvulsants','folate_metabolism_disorder','methotrexate_use'],'OR lógico das 5 indicações selecionadas para este cenário; não generalizar')
derived('folic_acid_dose',['folic_acid_started','high_risk_folic_acid_indication'],'NA se não iniciou; caso contrário 5000 μg/dia com indicação alta, 400 μg/dia sem indicação')
derived('total_weight_gain',['visit1_weight_kg']+[f'visit{i}_weight_kg' for i in range(2,8)]+[f'visit{i}_date' for i in range(2,8)],'último peso antenatal disponível antes do parto − visit1_weight_kg')
derived('postpartum_weight_loss',['visit8_weight_kg']+[f'visit{i}_weight_kg' for i in range(1,8)]+[f'visit{i}_date' for i in range(2,8)],'último peso antenatal disponível − visit8_weight_kg')
derived('contraceptive_method_in_use',['contraceptive_method'],"1 se contraceptive_method != 'none', senão 0")
derived('referred_to_mental_health',['EPDS_score'],'1 obrigatoriamente quando EPDS_score >=12; pode ser 1 com score inferior por outras causas', 'parcial: indicações adicionais de referenciação não exportadas')
derived('referred_to_gestational_diabetes_clinic',['pregestational_diabetes','fasting_glucose','OGTT_performed','OGTT_fasting_glucose','OGTT_1h_glucose','OGTT_2h_glucose'],'1 se diabetes prévia, fasting_glucose >=92 ou PTGO com pelo menos um limiar atingido; representa circuito, não diagnóstico universal')
derived('gestational_hypertension',['blood_pressure_week29_systolic','blood_pressure_week29_diastolic','repeated_third_trimester_blood_pressure_systolic','repeated_third_trimester_blood_pressure_diastolic','third_trimester_24h_proteinuria_mg'],'PA elevada nos dois pares e média sistólica >=140 ou média diastólica >=90; proteinúria <300; NA na ausência do painel','integral para fenótipo operacional; não equivale a diagnóstico clínico completo')
derived('preeclampsia',['blood_pressure_week29_systolic','blood_pressure_week29_diastolic','repeated_third_trimester_blood_pressure_systolic','repeated_third_trimester_blood_pressure_diastolic','third_trimester_24h_proteinuria_mg'],'PA elevada nos dois pares e média sistólica >=140 ou média diastólica >=90; proteinúria >=300; NA na ausência do painel','integral para fenótipo proteinúrico operacional; outros critérios clínicos ausentes')
derived('estimated_fetal_weight_third_trimester',['abdominal_circumference_third_trimester','head_circumference_third_trimester'],'Stirnemann et al. 2017, log(EFW g) = 5.084820−54.06633(AC cm/100)^3−95.80076(AC cm/100)^3 log(AC cm/100)+3.136370(HC cm/100); arredondamento g')
derived('estimated_fetal_weight_third_trimester_percentile',['estimated_fetal_weight_third_trimester'],'INTERGROWTH-21st Stirnemann 2017 LMS usando IG da ecografia em tabela auxiliar (não exportada); percentil contínuo quantizado metade-para-cima','parcial; idade real do exame em metadados auxiliares')
for k in [3,4,5,6,8]:derived(f'Goodwin_risk_visit{k}',[f'Goodwin_score_visit{k}'],'0–2 low; 3–6 medium; >=7 high')
for k in [3,4,5,6,8]:expanded.loc[expanded.nome==f'Goodwin_score_visit{k}','auditabilidade']='score sintético direto; itens constituintes não exportados'
for k in ['second_trimester_biometry']:
 expanded.loc[expanded.nome==k,['regra_derivacao','auditabilidade','momento_colheita']]=['SEMÂNTICA PENDENTE; manter NA; medida escalar não definida','não auditável / indefinida','2.º trimestre; definição clínica por esclarecer']
expanded.loc[expanded.nome=='uterine_fundal_height_postpartum','unidade_precisao']='0–8 cm acima sínfise púbica, às 4–6 semanas; 0 = não palpável'
expanded.loc[expanded.nome=='gestational_age_at_first_trimester_ultrasound_days','unidade_precisao']='63–97 dias, inteiro'
expanded.loc[expanded.nome=='estimated_fetal_weight_third_trimester_percentile','unidade_precisao']='1–99, inteiro; arredondamento metade para cima'
expanded.loc[expanded.nome=='postpartum_hemoglobin','momento_colheita']='1–3 dias pós-parto (distinto de visit8)'
expanded.loc[expanded.nome=='second_trimester_biometry','unidade_precisao']='SEMÂNTICA PENDENTE; NA em todas as linhas'
expanded.loc[expanded.nome=='birth_weight_g','auditabilidade']='medição sintética derivada de um modelo neonatal aproximado, não referência clínica publicada validada'
expanded.to_csv('/mnt/data/coorte_obstetrica/dicionario_expandido.csv',index=False,sep=';',encoding='utf-8-sig')
main.to_csv('/mnt/data/coorte_obstetrica/coorte_sintetica_5000x162.csv',index=False,encoding='utf-8-sig',na_rep='')
metadata.to_csv('/mnt/data/coorte_obstetrica/metadados_auxiliares.csv',index=False,encoding='utf-8-sig')
report.to_csv('/mnt/data/coorte_obstetrica/representacao_condicoes.csv',index=False,encoding='utf-8-sig')
co=pd.DataFrame(index=list(flags),columns=list(flags),dtype=int)
for x,v in flags.items():
 for y,w in flags.items():co.loc[x,y]=int((v&w).sum())
co.to_csv('/mnt/data/coorte_obstetrica/coocorrencias.csv',encoding='utf-8-sig')
# blocking integrity checks
assert main.shape==(5000,162) and main.columns.tolist()==COLS and main.patient_id.nunique()==5000
assert (main['estimated_fetal_weight_third_trimester_percentile'].dropna().astype(int).between(1,99)).all()
assert (main['gestational_age_at_first_trimester_ultrasound_days'].between(63,97)).all()
reps=main.dropna(subset=['repeated_third_trimester_blood_pressure_systolic','repeated_third_trimester_blood_pressure_diastolic'])
assert reps['repeated_third_trimester_blood_pressure_systolic'].between(80,200).all() and reps['repeated_third_trimester_blood_pressure_diastolic'].between(40,130).all() and (reps['repeated_third_trimester_blood_pressure_systolic']>reps['repeated_third_trimester_blood_pressure_diastolic']).all()
assert not ((main.macrosomia==1)&(main.fetal_growth_restriction==1)).any()
assert int(control.sum())>=1500 and all(int(v.sum())>=t for v,t in zip(flags.values(),[700,500,350,650,750,500,1500]))
assert ((pd.to_datetime(main.visit8_date)-pd.to_datetime(main.delivery_date)).dt.days.between(28,42)).all()
assert (main.preterm_birth==(main.gestational_age_at_delivery_weeks<37).astype(int)).all()
assert (main.macrosomia==(main.birth_weight_g>=4000).astype(int)).all()
assert ((main['delivery_date'].notna()) & (main['date_4_months_postpartum'].notna())).all()
print('CHECKS BLOCKING: passed')
