# Coorte obstétrica sintética — geração e limites de utilização

**Data:** 28-10-2026 · **Seed:** `20261028` · **Gerador:** `gerar.py` · **Amostra:** 5.000 trajetórias · **Schema principal:** exatamente 162 colunas, primeiro campo `patient_id`.

## Âmbito e estatuto

Todas as observações são **inteiramente sintéticas**. O gerador realiza um enriquecimento deliberado de fenótipos, pelo que **os números não são prevalências**. O dataset não foi submetido a avaliação clínica independente, calibração epidemiológica externa ou validação por especialistas. **Não se destina a cuidados de saúde ou estimativa de risco clínico.** A componente neonatal tem uma aproximação não validada e, portanto, o conjunto **não satisfaz integralmente o requisito de uma referência neonatal publicada corretamente implementada**.

## Construção das trajetórias

1. A partir da seed de NumPy, sorteiam-se perfis internos A/B/C/D/E/F/G/H (reservados à tabela de metadados, nunca ao CSV de 162 colunas). Propostas são rejeitadas e novamente geradas na íntegra quando não cumprem um fenótipo-alvo ou um suporte do modelo. A amostragem por perfis não constitui diagnóstico.
2. Estabelecem-se características basais, DUM, primeira ecografia, discrepância triangular [-10,+10] dias, EDD inicial e EDD corrigida pela regra operacional `abs(discrepância)>=7`. Todas as datas subsequentes contam da origem `EDD ajustada - 280 dias`. A consulta 2 só pode ocorrer nos dias 98 a 118, e a idade gestacional no parto resulta do número inteiro de dias decorrido.
3. Estabelecem-se propensões latentes para hiperglicemia, hipertensão, pré-eclâmpsia, nascimento pré-termo, crescimento reduzido/aumentado e os fatores de risco basais. As medições surgem de distribuições contínuas ou discretizadas com ruído, sem atribuição aleatória independente às flags finais. São usadas correlações positivas entre componentes de pressão arterial. A segunda pressão é uma nova amostra conjunta condicionada, nunca recortada para o suporte.
4. O parto ocorre tipicamente a termo ou, nas trajetórias pré-termo, em bandas: tardio ~70%, moderado ~12%, muito pré-termo ~12%, extremo ~6%. Os perfis de PE e anemia elevam probabilisticamente a propensão a prematuridade. As visitas antenatais e análises são truncadas em função do parto.
5. Glicemia de jejum, PTGO, hemoglobinas, PA, proteinúria, percentil fetal, peso à nascença, EPDS e scores são fixados e arredondados **antes** das flags. As flags resultam das regras do prompt, com valores NA quando não observáveis. A classificação operacional de DG, o controlo demonstrável, a origem gestacional, a data real da PTGO, o sexo neonatal auxiliar e a data da ecografia de crescimento ficam apenas na tabela auxiliar.
6. O ganho ponderal esperado aumenta progressivamente segundo IMC basal e duração da gravidez; `total_weight_gain` e `postpartum_weight_loss` são diferenças dos pesos efetivamente exportados. A consulta puerperal `visit8` ocorre 28–42 dias pós-parto; hemoglobina pós-parto é simulada como colhida nos primeiros 1–3 dias, e não na visit8. Os seguimentos de 4 e 6 meses são construídos por meses civis.

## Parâmetros internos de enriquecimento

Reservas de candidatas por perfil: A controlo 1600; B DG 650; C hipertensão gestacional 510; D pré-eclâmpsia 400; E macrossomia 650; F prematuridade 700; G FGR 430; H combinações 60. O gerador aceita apenas trajetórias completas elegíveis para cada perfil; os totais observados são computados posteriormente. As associações não são determinísticas. A representação de DG é elevada por seleção e pelas distribuições glicémicas, especialmente acima de 92 mg/dL. Esta característica pode limitar estudos de causalidade ou extrapolação.

## Regras operacionais e reconstrução

* **GDM:** compatibilidade metodológica com o perfil português 2017, sem alegar representar integralmente o consenso 2025. Se jejum inicial 92–125 mg/dL, referenciação sem PTGO. Se jejum inicial <92, PTGO 75 g na janela 24–28 semanas quando observável e sem diabetes prévia, com positividade se qualquer 0/1/2h >=92/180/153 mg/dL, excluindo resultados compatíveis com diabetes na gravidez (jejum PTGO >=126, 2 h >=200). Jejum inicial >=126 e diabetes prévia são separados da DG operacional. A data real da PTGO fica na tabela auxiliar.
* **PA e proteinúria:** a confirmação operacional requer cada par tensional com sistólica >=140 **ou** diastólica >=90, e média das sistólicas >=140 **ou** das diastólicas >=90. Proteinúria >=300 mg/24h classifica PE, caso contrário hipertensão gestacional. Não inclui PE não proteinúrica, hipertensão crónica ou PE sobreposta. A segunda PA obedece ao suporte 80–200/40–130 mmHg, com sistólica > diastólica. Sem observação após 29 semanas, as flags ficam NA.
* **FGR:** percentil inteiro do EFW <10, com a ecografia real guardada na tabela auxiliar; sem ecografia, o diagnóstico é NA. A restrição FGR e macrossomia são mutuamente excludentes **neste cenário**, não uma impossibilidade clínica universal.
* **Bilirrubinas, etc.:** não foram acrescentadas variáveis clínicas fora do schema. O campo agregado `second_trimester_biometry` permanece integralmente NA por semântica irresolvida; não interpretar como exame omitido.
* **Goodwin:** a categoria é derivada de 0–2 low; 3–6 medium; >=7 high. Os scores e extensão puerperal são simulações de um score agregado, não reconstituíveis dos itens clínicos.
* **Ácido fólico:** a regra de 5000 μg/dia usa cinco indicações selecionadas (DTN pessoal/familiar, anticonvulsivantes, alteração do metabolismo do folato, metotrexato); não é norma de prescrição universal.
* **Aleitamento:** estados representam alimentação corrente; a possibilidade de relactação é preservada, não se trata de exclusividade cumulativa desde o nascimento. Aos 6 meses 'exclusive' refere-se apenas à categoria de alimentação atual do desenho.

## Crescimento antenatal e referência implementada

Foi usada efetivamente a **fórmula INTERGROWTH-21st para estimativa de peso fetal** publicada por Stirnemann et al. (2017), válida no intervalo do estudo, com AC e HC em cm (exportadas em mm):

`ln(EFW[g]) = 5.084820 - 54.06633 (AC[cm]/100)^3 - 95.80076 (AC[cm]/100)^3 ln(AC[cm]/100) + 3.136370 (HC[cm]/100)`.

Os percentis são reconstruídos com os coeficientes lambda, mu e sigma publicados na tabela 2 do mesmo artigo e a idade gestacional da ecografia auxiliar (selecionada aproximadamente entre 31 e 33 semanas): `Y=ln(EFW); Z=((Y/mu)^lambda-1)/(sigma*lambda); percentil=100*Phi(Z)`. O percentil é arredondado metade-para-cima para inteiro 1–99; propostas que dão 0 ou 100 são rejeitadas, não truncadas. O percentil clínico **não pode ser reconstruído exclusivamente** do CSV principal por falta da data real da ecografia. FL é correlacionado com AC/HC mas **não entra na fórmula EFW escolhida**, que usa efetivamente as duas variáveis disponíveis. A parametrização do percentil representa o padrão de EFW do artigo, e não um `Phi(z)` de referência inventada.

**Referência:** Stirnemann et al. *Ultrasound in Obstetrics & Gynecology* (2017), DOI [10.1002/uog.17347](https://doi.org/10.1002/uog.17347).

## Limitação importante — peso neonatal

O peso ao nascer utiliza uma **aproximação sintética com interpolação entre nós por semana** (20:360 g; 22:480; 24:640; 26:850; 28:1100; 30:1400; 32:1760; 34:2220; 36:2670; 37:2910; 38:3110; 39:3290; 40:3430; 41:3540; 42:3650; 43:3720), multiplicada por `exp(0,105 × desvio_latente_crescimento + ε)` com `ε~N(0;0,086²)`. **Esses nós NÃO são identificados como coeficientes, centis ou tabelas oficiais de INTERGROWTH.** Constituem aproximações operacionais e não foi quantificado o erro relativamente a uma tabela neonatal publicada. Não há implementação validada das referências distintas para muito pré-termo e termo. A variável `birth_weight_g` e consequências (incluindo macrossomia) devem ser consideradas **exploratórias e não plenamente conformes** à exigência de referência neonatal da especificação. O sexo neonatal da tabela auxiliar foi simulado mas não foi utilizado para a distribuição de peso (evitando uma pretensão falsa de ajuste por sexo). A amplitude 300–6000 g representa o suporte de exportação.

Referências propostas mas **não implementadas numericamente** no peso neonatal: Villar et al., Lancet 2014, PMID 25209487; Villar et al., Lancet 2016, PMID 26898853; INTERGROWTH-21st newborn-size-at-birth e very-preterm-size-at-birth. Uma revisão posterior deve substituir esta aproximação pela tabela/equação correspondente antes de qualquer uso clínico ou publicação científica que exija adesão completa.

## Fontes, convenções e precisão

* OMS, *Guideline on haemoglobin cutoffs to define anaemia in individuals and populations*, 2024: limiares trimestrais de 11/10,5/11 g/dL, com sinal `<` estrito. `postpartum_anemia <10` é convenção do projeto, e hemoglobina pós-parto corresponde a 1–3 dias após parto.
* Consenso português de DG 2017, critérios operacionais de rastreio 75 g; a versão de 2025 é distinta e **não está inteiramente implementada**.
* ISSHP 2021/2022: enquadramento clínico; a regra baseada apenas em PA e proteinúria é simplificação do projeto, não diagnóstico clínico universal.
* ISUOG 2019: enquadramento de biometria, mas a fórmula numérica implementada é a de Stirnemann 2017 citada acima.
* DGS Norma 001/2023, atualização 23-03-2026: enquadramento de cuidados pré-natais; as janelas selecionadas no dataset são convenções do projeto.
* Pressões e glicemias inteiras; hemoglobina e peso materno uma casa decimal; IMC duas casas; pesos neonatais e EFW inteiros; datas ISO; percentis inteiros; scores inteiros; `birth_weight_g` e `Bishop_score` inteiros.

## Limitações de ML/XAI

Evitar incorporar simultaneamente uma flag determinística e a sua variável-base como duas dimensões independentes em clustering (exemplos: peso neonatal/macrossomia, idade gestacional/prematuridade, Hb/anemia, EPDS/EPDS>=12, EFW/percentil/FGR, PA/proteinúria/hipertensão/PE). Evitar variáveis pós-parto como preditoras de eventos antenatais, bem como datas ou intervenções posteriores à data pretendida para a previsão. A amostragem condicionada e a ausência de covariáveis relevantes geram viés de seleção e comprometem calibração preditiva.

## Ficheiros e auditabilidade

- `coorte_sintetica_5000x162.csv`: apenas o schema original, com `patient_id` primeiro.
- `dicionario_expandido.csv`: descrição e documentação de cada variável, conservando os campos originais e acrescentando bases, derivação e auditabilidade.
- `metadados_auxiliares.csv`: perfil interno, data efetiva da PTGO e ecografia de crescimento, percentil contínuo, origem gestacional, sexo auxiliar, DG operacional e controlo verificável. **Não utilizar diretamente para treino preditivo**, pois contém informação de geração e estado dos desfechos.
- `representacao_condicoes.csv`: totais, percentagens, denominadores observáveis, quotas de desenho.
- `coocorrencias.csv`: tabela cruzada de condições-alvo e controlos.
- `gerar.py`: gerador reproduzível com a seed fixa, dependências NumPy, Pandas, SciPy e python-dateutil.

As verificações programáticas incluídas são de consistência estrutural e regras selecionadas da geração, **não equivalem a validação independente do resultado**. A semântica de `second_trimester_biometry`, a referência neonatal e a auditabilidade clínica de vários diagnósticos exigem resolução metodológica posterior.
